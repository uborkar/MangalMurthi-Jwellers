import React, { useState } from "react";

interface ReturnItem {
  productName: string;
  category: string;
  quantity: number;
  weight: string;
  condition: string;
  remarks: string;
}

const Returns: React.FC = () => {
  const [items, setItems] = useState<ReturnItem[]>([
    { productName: "", category: "", quantity: 1, weight: "", condition: "", remarks: "" },
  ]);

  const addRow = () => {
    setItems([
      ...items,
      { productName: "", category: "", quantity: 1, weight: "", condition: "", remarks: "" },
    ]);
  };

  const updateItem = <K extends keyof ReturnItem>(
    index: number,
    field: K,
    value: ReturnItem[K]
  ) => {
    const updated = [...items];
    updated[index][field] = value;
    setItems(updated);
  };

  const removeRow = (index: number) => {
    if (items.length === 1) return;
    setItems(items.filter((_, i) => i !== index));
  };

  const handleSubmit = () => {
    console.log("Returned Items:", items);
    alert("Returns submitted! (Backend integration coming soon)");
  };

  return (
    <div className="p-6 bg-white shadow rounded-md">
      <h1 className="text-2xl font-semibold mb-6">Return Items to Warehouse</h1>

      {/* Return Items */}
      <div className="space-y-4">
        {items.map((row, index) => (
          <div
            key={index}
            className="p-4 border rounded-md bg-gray-50 grid md:grid-cols-6 gap-4"
          >
            <input
              type="text"
              placeholder="Product Name"
              className="input-style"
              value={row.productName}
              onChange={(e) => updateItem(index, "productName", e.target.value)}
            />

            <input
              type="text"
              placeholder="Category"
              className="input-style"
              value={row.category}
              onChange={(e) => updateItem(index, "category", e.target.value)}
            />

            <input
              type="number"
              placeholder="Qty"
              className="input-style"
              value={row.quantity}
              onChange={(e) => updateItem(index, "quantity", Number(e.target.value))}
            />

            <input
              type="text"
              placeholder="Weight"
              className="input-style"
              value={row.weight}
              onChange={(e) => updateItem(index, "weight", e.target.value)}
            />

            <select
              className="input-style"
              value={row.condition}
              onChange={(e) => updateItem(index, "condition", e.target.value)}
            >
              <option value="">Condition</option>
              <option value="Good">Good</option>
              <option value="Polishing Needed">Polishing Needed</option>
              <option value="Damaged">Damaged</option>
            </select>

            <input
              type="text"
              placeholder="Remarks"
              className="input-style"
              value={row.remarks}
              onChange={(e) => updateItem(index, "remarks", e.target.value)}
            />

            <div className="flex items-center justify-center col-span-6 md:col-span-1">
              <button
                className="px-3 py-1 bg-red-500 text-white rounded hover:bg-red-600"
                onClick={() => removeRow(index)}
              >
                Remove
              </button>
            </div>
          </div>
        ))}
      </div>

      {/* Add More */}
      <button
        className="mt-5 px-4 py-2 bg-blue-600 text-white rounded hover:bg-blue-700"
        onClick={addRow}
      >
        + Add Another Returned Item
      </button>

      {/* Submit */}
      <button
        className="mt-5 ml-4 px-6 py-2 bg-green-600 text-white rounded hover:bg-green-700"
        onClick={handleSubmit}
      >
        Submit Returns
      </button>
    </div>
  );
};

export default Returns;
