import React, { useState } from "react";
import * as XLSX from "xlsx";

interface StockItem {
  productName: string;
  category: string;
  quantity: number;
  weight: string;
  costPrice: number;
  remarks: string;
}

interface ExcelRow {
  ProductName: string;
  Category: string;
  Quantity: number;
  Weight: string;
  CostPrice: number;
  Remarks: string;
}

const StockIn: React.FC = () => {
  const [items, setItems] = useState<StockItem[]>([
    { productName: "", category: "", quantity: 1, weight: "", costPrice: 0, remarks: "" },
  ]);

  const addRow = () => {
    setItems([
      ...items,
      { productName: "", category: "", quantity: 1, weight: "", costPrice: 0, remarks: "" },
    ]);
  };

  const updateItem = <K extends keyof StockItem>(
    index: number,
    field: K,
    value: StockItem[K]
  ) => {
    const updated = [...items];
    updated[index][field] = value;
    setItems(updated);
  };

  const removeRow = (index: number) => {
    if (items.length === 1) return;
    setItems(items.filter((_, i) => i !== index));
  };

  // =========================================================
  // 🔵 Excel Upload Handler
  // =========================================================
  const handleFileUpload = (event: React.ChangeEvent<HTMLInputElement>) => {
    const file = event.target.files?.[0];
    if (!file) return;

    const reader = new FileReader();

    reader.onload = (e) => {
      const data = e.target?.result;
      const workbook = XLSX.read(data as string, { type: "binary" });

      const sheetName = workbook.SheetNames[0];
      const sheet = workbook.Sheets[sheetName];

      const excelData = XLSX.utils.sheet_to_json(sheet) as ExcelRow[];

      excelData.forEach((row) => {
        const newRow: StockItem = {
          productName: row.ProductName || "",
          category: row.Category || "",
          quantity: Number(row.Quantity) || 1,
          weight: row.Weight || "",
          costPrice: Number(row.CostPrice) || 0,
          remarks: row.Remarks || "",
        };

        setItems((prev) => [...prev, newRow]);
      });

      alert(`Imported ${excelData.length} stock items from Excel`);
    };

    reader.readAsBinaryString(file);
  };

  const handleSubmit = () => {
    console.log("Submitting Warehouse Stock:", items);
    alert("Stock-In submitted. (Backend integration soon)");
  };

  return (
   
    <div className="p-6 bg-white shadow rounded-md">
      <h1 className="text-2xl font-semibold mb-6">Warehouse - Stock In</h1>

      {/* ---------------------- Excel Upload ---------------------- */}
      <div className="mb-8">
        <h2 className="text-xl font-semibold mb-3">Upload Stock from Excel</h2>

        <div
          className="border-2 border-dashed border-blue-400 rounded-lg p-8 text-center cursor-pointer hover:bg-blue-50 transition"
          onClick={() => document.getElementById("excelUploadStock")?.click()}
        >
          <input
            id="excelUploadStock"
            type="file"
            accept=".xlsx, .xls, .csv"
            className="hidden"
            onChange={handleFileUpload}
          />

          <div className="flex flex-col items-center">
            <div className="rounded-full bg-blue-100 h-16 w-16 flex items-center justify-center mb-3">
              <span className="text-blue-500 text-3xl">📦</span>
            </div>
            <p className="text-gray-700 font-medium">Click to upload Stock Excel file</p>
            <p className="text-sm text-gray-500">Supported: XLSX, CSV</p>
          </div>
        </div>
      </div>

      <div className="space-y-4">
        {items.map((row, index) => (
          <div key={index} className="p-4 border rounded-md bg-gray-50 grid md:grid-cols-6 gap-4">

            <input
              type="text"
              placeholder="Product Name"
              className="input-style"
              value={row.productName}
              onChange={(e) => updateItem(index, "productName", e.target.value)}
            />

            <input
              type="text"
              placeholder="Category"
              className="input-style"
              value={row.category}
              onChange={(e) => updateItem(index, "category", e.target.value)}
            />

            <input
              type="number"
              placeholder="Qty"
              className="input-style"
              value={row.quantity}
              onChange={(e) => updateItem(index, "quantity", Number(e.target.value))}
            />

            <input
              type="text"
              placeholder="Weight"
              className="input-style"
              value={row.weight}
              onChange={(e) => updateItem(index, "weight", e.target.value)}
            />

            <input
              type="number"
              placeholder="Cost Price"
              className="input-style"
              value={row.costPrice}
              onChange={(e) => updateItem(index, "costPrice", Number(e.target.value))}
            />

            <input
              type="text"
              placeholder="Remarks"
              className="input-style"
              value={row.remarks}
              onChange={(e) => updateItem(index, "remarks", e.target.value)}
            />

            <div className="flex items-center justify-center col-span-6 md:col-span-1">
              <button
                className="px-3 py-1 bg-red-500 text-white rounded hover:bg-red-600"
                onClick={() => removeRow(index)}
              >
                Remove
              </button>
            </div>
          </div>
        ))}
      </div>

      <button
        className="mt-5 px-4 py-2 bg-blue-600 text-white rounded hover:bg-blue-700"
        onClick={addRow}
      >
        + Add Another Item
      </button>

      <button
        className="mt-5 ml-4 px-6 py-2 bg-green-600 text-white rounded hover:bg-green-700"
        onClick={handleSubmit}
      >
        Submit Stock
      </button>
    </div>
  );
};

export default StockIn;
