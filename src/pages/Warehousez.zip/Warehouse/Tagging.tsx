import React, { useState } from "react";
import * as XLSX from "xlsx";

interface ExcelRow {
  Category: string;
  Weight: string;
  Price: number;
  Purity: string;
}

interface TagItem {
  label: string;
  category: string;
  year: string;
  location: string;
  serial: number;
  weight: string;
  price: number;
  purity: string;
}

const Tagging: React.FC = () => {
  const currentYear = new Date().getFullYear().toString().slice(2);

  const categoryPrefixes: Record<string, string> = {
    MangalSutra: "MS",
    Ring: "RN",
    Necklace: "NK",
    Earrings: "ER",
    Bracelet: "BR",
  };

  const locationCodes = ["MM", "SG", "MJ", "KL"];

  const [selectedCategory, setSelectedCategory] = useState("");
  const [selectedLocation, setSelectedLocation] = useState("");
  const [serial, setSerial] = useState(1);

  const [weight, setWeight] = useState("");
  const [price, setPrice] = useState<number>(0);
  const [purity, setPurity] = useState("");

  const [generatedLabel, setGeneratedLabel] = useState("");
  const [tags, setTags] = useState<TagItem[]>([]);

  // =========================================================
  // 🔵 Generate Manual Label
  // =========================================================
  const generateLabel = () => {
    if (!selectedCategory || !selectedLocation) {
      alert("Select category and location");
      return;
    }

    const prefix = categoryPrefixes[selectedCategory];
    const finalLabel = `${prefix}${currentYear}/${selectedLocation}/${serial}`;

    setGeneratedLabel(finalLabel);
  };

  // =========================================================
  // 🔵 Add Manual Tag
  // =========================================================
  const addTagToList = () => {
    if (!generatedLabel) {
      alert("Please generate label first");
      return;
    }

    const newTag: TagItem = {
      label: generatedLabel,
      category: selectedCategory,
      year: currentYear,
      location: selectedLocation,
      serial,
      weight,
      price,
      purity,
    };

    setTags((prev) => [...prev, newTag]);
    setSerial((prev) => prev + 1);
    setGeneratedLabel("");
    setWeight("");
    setPrice(0);
    setPurity("");
  };

  // =========================================================
  // 🔵 Excel Upload Handler
  // =========================================================
  const handleFileUpload = (event: React.ChangeEvent<HTMLInputElement>) => {
    const file = event.target.files?.[0];
    if (!file) return;

    const reader = new FileReader();

    reader.onload = (e) => {
      const data = e.target?.result;
      const workbook = XLSX.read(data as string, { type: "binary" });

      const sheetName = workbook.SheetNames[0];
      const sheet = workbook.Sheets[sheetName];

      const excelData = XLSX.utils.sheet_to_json(sheet) as ExcelRow[];

      excelData.forEach((item, i) => {
        const prefix = categoryPrefixes[item.Category];
        const finalLabel = `${prefix}${currentYear}/${selectedLocation || "MM"}/${serial + i}`;

        const newTag: TagItem = {
          label: finalLabel,
          category: item.Category,
          year: currentYear,
          location: selectedLocation || "MM",
          serial: serial + i,
          weight: item.Weight,
          price: item.Price,
          purity: item.Purity,
        };

        setTags((prev) => [...prev, newTag]);
      });

      setSerial((prev) => prev + excelData.length);
      alert(`Imported ${excelData.length} products from Excel`);
    };

    reader.readAsBinaryString(file);
  };

  return (
    <div className="p-6 bg-white shadow rounded">

      <h1 className="text-2xl font-semibold mb-6">Tagging & Labeling</h1>

      {/* ---------------------- Excel Upload UI ---------------------- */}
      <div className="mb-8">
        <h2 className="text-xl font-semibold mb-3">Upload Items from Excel</h2>

        <div
          className="border-2 border-dashed border-blue-400 rounded-lg p-8 text-center cursor-pointer hover:bg-blue-50 transition"
          onClick={() => document.getElementById("excelUpload")?.click()}
        >
          <input
            id="excelUpload"
            type="file"
            accept=".xlsx, .xls, .csv"
            className="hidden"
            onChange={handleFileUpload}
          />

          <div className="flex flex-col items-center">
            <div className="rounded-full bg-blue-100 h-16 w-16 flex items-center justify-center mb-3">
              <span className="text-blue-500 text-3xl">📄</span>
            </div>
            <p className="text-gray-700 font-medium">Click to upload Excel file</p>
            <p className="text-sm text-gray-500">Supported: XLSX, CSV</p>
          </div>
        </div>
      </div>

      {/* ------------------------ Manual Tagging Form ------------------------ */}
      <div className="grid grid-cols-1 md:grid-cols-3 gap-4 mb-6">

        <div>
          <label className="font-medium">Item Category</label>
          <select
            className="w-full border p-2 rounded"
            value={selectedCategory}
            onChange={(e) => setSelectedCategory(e.target.value)}
          >
            <option value="">Select Category</option>
            {Object.keys(categoryPrefixes).map((cat) => (
              <option key={cat} value={cat}>{cat}</option>
            ))}
          </select>
        </div>

        <div>
          <label className="font-medium">Location Code</label>
          <select
            className="w-full border p-2 rounded"
            value={selectedLocation}
            onChange={(e) => setSelectedLocation(e.target.value)}
          >
            <option value="">Select Location</option>
            {locationCodes.map((loc) => (
              <option key={loc} value={loc}>{loc}</option>
            ))}
          </select>
        </div>

        <div>
          <label className="font-medium">Serial No</label>
          <input
            type="number"
            className="w-full border p-2 rounded"
            value={serial}
            onChange={(e) => setSerial(Number(e.target.value))}
          />
        </div>

        <div>
          <label className="font-medium">Weight (gms)</label>
          <input
            className="w-full border p-2 rounded"
            value={weight}
            onChange={(e) => setWeight(e.target.value)}
            placeholder="Ex: 12.50"
          />
        </div>

        <div>
          <label className="font-medium">Purity</label>
          <input
            className="w-full border p-2 rounded"
            value={purity}
            onChange={(e) => setPurity(e.target.value)}
            placeholder="Ex: 916"
          />
        </div>

        <div>
          <label className="font-medium">Price (₹)</label>
          <input
            type="number"
            className="w-full border p-2 rounded"
            value={price}
            onChange={(e) => setPrice(Number(e.target.value))}
          />
        </div>
      </div>

      {/* Generate Manual Label */}
      <button
        className="px-4 py-2 bg-blue-600 text-white rounded hover:bg-blue-700"
        onClick={generateLabel}
      >
        Generate Label
      </button>

      {generatedLabel && (
        <div className="mt-4 p-4 border rounded bg-gray-100 text-center text-lg font-bold">
          {generatedLabel}
        </div>
      )}

      {generatedLabel && (
        <button
          className="mt-4 px-4 py-2 bg-green-600 text-white rounded hover:bg-green-700"
          onClick={addTagToList}
        >
          Add to List
        </button>
      )}

      {/* ---------------------- Tag List Table ---------------------- */}
      {tags.length > 0 && (
        <div className="mt-8">
          <h2 className="text-xl font-semibold mb-3">Generated Tags</h2>

          <table className="w-full border">
            <thead className="bg-gray-200">
              <tr>
                <th className="border p-2">Label</th>
                <th className="border p-2">Category</th>
                <th className="border p-2">Weight</th>
                <th className="border p-2">Purity</th>
                <th className="border p-2">Price</th>
              </tr>
            </thead>
            <tbody>
              {tags.map((t, i) => (
                <tr key={i} className="text-center">
                  <td className="border p-2">{t.label}</td>
                  <td className="border p-2">{t.category}</td>
                  <td className="border p-2">{t.weight}</td>
                  <td className="border p-2">{t.purity}</td>
                  <td className="border p-2">₹{t.price}</td>
                </tr>
              ))}
            </tbody>
          </table>

          <button className="mt-4 px-5 py-2 bg-purple-600 text-white rounded hover:bg-purple-700">
            Save All Tags (coming soon)
          </button>
        </div>
      )}
    </div>
  );
};

export default Tagging;
