import React, { useState } from "react";

interface DistributionItem {
  productName: string;
  category: string;
  quantity: number;
  weight: string;
}

const Distribution: React.FC = () => {
  const shops = ["Sangli", "Miraj", "Kolhapur"];

  const [selectedShop, setSelectedShop] = useState("");
  const [items, setItems] = useState<DistributionItem[]>([
    { productName: "", category: "", quantity: 1, weight: "" },
  ]);

  const addRow = () => {
    setItems([
      ...items,
      { productName: "", category: "", quantity: 1, weight: "" },
    ]);
  };

  const updateItem = <K extends keyof DistributionItem>(
    index: number,
    field: K,
    value: DistributionItem[K]
  ) => {
    const updated = [...items];
    updated[index][field] = value;
    setItems(updated);
  };

  const removeRow = (index: number) => {
    if (items.length === 1) return;
    setItems(items.filter((_, i) => i !== index));
  };

  const handleSubmit = () => {
    if (!selectedShop) {
      alert("Please select a shop");
      return;
    }

    console.log("Distributing to:", selectedShop);
    console.log("Items:", items);

    alert(`Distributed ${items.length} items to ${selectedShop}`);
  };

  return (
    <div className="p-6 bg-white shadow rounded-md">
      <h1 className="text-2xl font-semibold mb-6">Distribute to Shops</h1>

      {/* Select shop */}
      <div className="mb-6">
        <label className="font-medium">Select Shop</label>
        <select
          className="w-full border p-2 rounded mt-1"
          value={selectedShop}
          onChange={(e) => setSelectedShop(e.target.value)}
        >
          <option value="">Choose shop</option>
          {shops.map((shop) => (
            <option key={shop} value={shop}>
              {shop}
            </option>
          ))}
        </select>
      </div>

      {/* Distribution items */}
      <div className="space-y-4">
        {items.map((row, index) => (
          <div
            key={index}
            className="p-4 border rounded-md bg-gray-50 grid md:grid-cols-5 gap-4"
          >
            <input
              type="text"
              placeholder="Product Name"
              className="input-style"
              value={row.productName}
              onChange={(e) => updateItem(index, "productName", e.target.value)}
            />

            <input
              type="text"
              placeholder="Category"
              className="input-style"
              value={row.category}
              onChange={(e) => updateItem(index, "category", e.target.value)}
            />

            <input
              type="number"
              placeholder="Qty"
              className="input-style"
              value={row.quantity}
              onChange={(e) =>
                updateItem(index, "quantity", Number(e.target.value))
              }
            />

            <input
              type="text"
              placeholder="Weight"
              className="input-style"
              value={row.weight}
              onChange={(e) => updateItem(index, "weight", e.target.value)}
            />

            <div className="flex items-center justify-center">
              <button
                className="px-3 py-1 bg-red-500 text-white rounded hover:bg-red-600"
                onClick={() => removeRow(index)}
              >
                Remove
              </button>
            </div>
          </div>
        ))}
      </div>

      {/* Add row */}
      <button
        className="mt-5 px-4 py-2 bg-blue-600 text-white rounded hover:bg-blue-700"
        onClick={addRow}
      >
        + Add Another Item
      </button>

      {/* Submit */}
      <button
        className="mt-5 ml-4 px-6 py-2 bg-green-600 text-white rounded hover:bg-green-700"
        onClick={handleSubmit}
      >
        Submit Distribution
      </button>
    </div>
  );
};

export default Distribution;
