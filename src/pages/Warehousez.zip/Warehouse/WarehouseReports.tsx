import React, { useState } from "react";
import { Download, Filter, RefreshCw } from "lucide-react";

const WarehouseReport: React.FC = () => {
  const [startDate, setStartDate] = useState("");
  const [endDate, setEndDate] = useState("");
  const [category, setCategory] = useState("");
  const [type, setType] = useState("");

  const handleSearch = () => {
    alert("Searching with filters (Backend integration next)");
  };

  const exportExcel = () => {
    alert("Excel Export coming soon");
  };

  const exportPDF = () => {
    alert("PDF Export coming soon");
  };

  return (
    <div className="p-6 space-y-8">

      {/* ------------------ Dashboard Header ------------------ */}
      <h1 className="text-3xl font-bold text-gray-800 dark:text-white">
        📦 Warehouse Analytics Dashboard
      </h1>

      {/* ------------------ Summary Cards ------------------ */}
      <div className="grid grid-cols-1 md:grid-cols-4 gap-6">

        <div className="p-5 bg-gradient-to-br from-blue-50 to-blue-100 dark:from-gray-800 dark:to-gray-700 rounded-xl shadow hover:scale-[1.02] transition">
          <p className="text-sm text-gray-600">Total Items</p>
          <h2 className="text-3xl font-bold text-blue-600">1,250</h2>
        </div>

        <div className="p-5 bg-gradient-to-br from-green-50 to-green-100 dark:from-gray-800 dark:to-gray-700 rounded-xl shadow hover:scale-[1.02] transition">
          <p className="text-sm text-gray-600">Total Weight</p>
          <h2 className="text-3xl font-bold text-green-600">8,742 gms</h2>
        </div>

        <div className="p-5 bg-gradient-to-br from-orange-50 to-orange-100 dark:from-gray-800 dark:to-gray-700 rounded-xl shadow hover:scale-[1.02] transition">
          <p className="text-sm text-gray-600">Distributed</p>
          <h2 className="text-3xl font-bold text-orange-600">540</h2>
        </div>

        <div className="p-5 bg-gradient-to-br from-red-50 to-red-100 dark:from-gray-800 dark:to-gray-700 rounded-xl shadow hover:scale-[1.02] transition">
          <p className="text-sm text-gray-600">Returned</p>
          <h2 className="text-3xl font-bold text-red-600">62</h2>
        </div>

      </div>

      {/* ------------------ Filters Section ------------------ */}
      <div className="p-6 bg-white dark:bg-gray-800 rounded-xl shadow">
        <h2 className="text-xl font-semibold mb-4 flex items-center gap-2">
          <Filter size={20} /> Filters
        </h2>

        <div className="grid md:grid-cols-4 gap-4">

          <input
            type="date"
            className="input-style"
            value={startDate}
            onChange={(e) => setStartDate(e.target.value)}
          />

          <input
            type="date"
            className="input-style"
            value={endDate}
            onChange={(e) => setEndDate(e.target.value)}
          />

          <select
            className="input-style"
            value={category}
            onChange={(e) => setCategory(e.target.value)}
          >
            <option value="">All Categories</option>
            <option value="MangalSutra">MangalSutra</option>
            <option value="Ring">Ring</option>
            <option value="Necklace">Necklace</option>
            <option value="Earrings">Earrings</option>
            <option value="Bracelet">Bracelet</option>
          </select>

          <select
            className="input-style"
            value={type}
            onChange={(e) => setType(e.target.value)}
          >
            <option value="">All Types</option>
            <option value="StockIn">Stock In</option>
            <option value="Tagging">Tagging</option>
            <option value="Distribution">Distribution</option>
            <option value="Return">Return</option>
          </select>
        </div>

        <button
          onClick={handleSearch}
          className="mt-5 px-6 py-2 bg-blue-600 hover:bg-blue-700 text-white rounded-lg shadow"
        >
          Apply Filters
        </button>
      </div>

      {/* ------------------ Chart Placeholder ------------------ */}
      <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
        {/* Stock In vs Distributed */}
        <div className="p-6 bg-white dark:bg-gray-800 rounded-xl shadow">
          <h2 className="text-lg font-semibold mb-3">📈 Stock In vs Distributed</h2>
          <div className="h-48 bg-gray-100 dark:bg-gray-700 rounded flex items-center justify-center">
            Charts Coming Soon
          </div>
        </div>

        {/* Category-wise Stock */}
        <div className="p-6 bg-white dark:bg-gray-800 rounded-xl shadow">
          <h2 className="text-lg font-semibold mb-3">📊 Category-wise Stock</h2>
          <div className="h-48 bg-gray-100 dark:bg-gray-700 rounded flex items-center justify-center">
            Charts Coming Soon
          </div>
        </div>
      </div>

      {/* ------------------ Report Table ------------------ */}
      <div className="p-6 bg-white dark:bg-gray-800 rounded-xl shadow">

        <div className="flex justify-between mb-4">
          <h2 className="text-xl font-semibold">Report Results</h2>

          <div className="flex gap-3">
            <button
              onClick={exportExcel}
              className="px-4 py-2 flex items-center gap-2 bg-green-600 hover:bg-green-700 text-white rounded"
            >
              <Download size={18} /> Excel
            </button>

            <button
              onClick={exportPDF}
              className="px-4 py-2 flex items-center gap-2 bg-red-600 hover:bg-red-700 text-white rounded"
            >
              <Download size={18} /> PDF
            </button>
          </div>
        </div>

        <table className="w-full border text-sm">
          <thead className="bg-gray-200 dark:bg-gray-700">
            <tr>
              <th className="border p-2">Date</th>
              <th className="border p-2">Action</th>
              <th className="border p-2">Item</th>
              <th className="border p-2">Category</th>
              <th className="border p-2">Qty</th>
              <th className="border p-2">Weight</th>
              <th className="border p-2">Shop / Status</th>
            </tr>
          </thead>

          <tbody>
            <tr className="text-center">
              <td className="border p-2" colSpan={7}>
                No data found (connect Firestore next)
              </td>
            </tr>
          </tbody>
        </table>
      </div>

    </div>
  );
};

export default WarehouseReport;
