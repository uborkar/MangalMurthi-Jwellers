// src/pages/Shops/SalesBooking.tsx - Sales Booking/Order Management
import { useState, useEffect } from "react";
import TASection from "../../components/common/TASection";
import PageMeta from "../../components/common/PageMeta";
import CustomDropdown from "../../components/common/CustomDropdown";
import toast from "react-hot-toast";
import { Calendar, Phone, Package, Plus, Trash2, Save, FileText, Printer, Download, ShoppingCart } from "lucide-react";
import { doc, setDoc, collection, query, orderBy, limit, getDocs } from "firebase/firestore";
import { db } from "../../firebase/config";
import * as XLSX from "xlsx";
import { jsPDF } from "jspdf";
import autoTable from "jspdf-autotable";
import BarcodeScanner from "../../components/common/BarcodeScanner";
import { getShopStock, BranchStockItem } from "../../firebase/shopStock";
import { getItemByBarcode } from "../../firebase/warehouseItems";
import { createBookingLedgerEntry } from "../../firebase/ledger";
import { useShop } from "../../context/ShopContext";

type BranchName = "Sangli" | "Miraj" | "Kolhapur" | "Mumbai" | "Pune" | string;

interface BookingItem {
  id: string;
  barcode?: string;
  itemName: string;
  stoneSapphire: string; // Stone/Sapphire details
  trNo: string; // Transfer Number
  pieces: number;
  weight: string;
  total: number;
}

const DEFAULT_BRANCHES: string[] = ["Sangli", "Miraj", "Kolhapur", "Mumbai", "Pune"];

export default function SalesBooking() {
  const { branchStockCache, setBranchStockCache, currentBooking, updateBooking, clearBooking } = useShop();

  const [selectedBranch, setSelectedBranch] = useState<BranchName>(currentBooking.branch);

  // Customer Details - Initialize from context
  const [partyName, setPartyName] = useState(currentBooking.partyName);
  const [mobileNo, setMobileNo] = useState(currentBooking.mobileNo);
  const [deliveryDate, setDeliveryDate] = useState(currentBooking.deliveryDate);

  // Salesperson
  const [salespersonName, setSalespersonName] = useState(currentBooking.salespersonName);

  // Booking Items - Initialize from context
  const [bookingItems, setBookingItems] = useState<BookingItem[]>(currentBooking.items);

  // Branch Stock
  const [branchStock, setBranchStock] = useState<BranchStockItem[]>(branchStockCache[selectedBranch] || []);
  const [loading, setLoading] = useState(false);

  // Payment Details - Initialize from context
  const [netAmount, setNetAmount] = useState(currentBooking.netAmount);
  const [cashAdvance, setCashAdvance] = useState(currentBooking.cashAdvance);
  const [pendingAmount, setPendingAmount] = useState(currentBooking.pendingAmount);
  const [totalAmount, setTotalAmount] = useState(0);

  // Additional Info
  const [remarks, setRemarks] = useState(currentBooking.remarks);

  // History
  const [showHistory, setShowHistory] = useState(false);
  const [lastBooking, setLastBooking] = useState<any>(null);

  // Preview Modal
  const [showPreviewModal, setShowPreviewModal] = useState(false);
  const [savedBookingData, setSavedBookingData] = useState<any>(null);

  // Dynamic branches list
  const [branches, setBranches] = useState<string[]>(DEFAULT_BRANCHES);

  // Handler to add new branch
  const handleAddBranch = (newBranch: string) => {
    if (!branches.includes(newBranch)) {
      setBranches([...branches, newBranch]);
      toast.success(`Added new branch: ${newBranch}`);
    }
  };

  // Sync with context whenever booking data changes (with debounce)
  useEffect(() => {
    const timeoutId = setTimeout(() => {
      try {
        updateBooking({
          branch: selectedBranch,
          items: bookingItems,
          partyName,
          mobileNo,
          deliveryDate,
          salespersonName,
          netAmount,
          cashAdvance,
          pendingAmount,
          remarks,
        });
      } catch (error) {
        console.error("Error updating booking context:", error);
      }
    }, 500); // Debounce 500ms

    return () => clearTimeout(timeoutId);
  }, [bookingItems, selectedBranch, partyName, mobileNo, deliveryDate, salespersonName, netAmount, cashAdvance, pendingAmount, remarks]);

  // Load branch stock (with caching)
  useEffect(() => {
    loadBranchStock();
  }, [selectedBranch]);

  const loadBranchStock = async () => {
    // Check cache first
    if (branchStockCache[selectedBranch] && branchStockCache[selectedBranch].length > 0) {
      const available = branchStockCache[selectedBranch].filter((s) => s.status === "in-branch" || !s.status);
      setBranchStock(available);
      console.log(`✅ Loaded ${available.length} items from cache for ${selectedBranch}`);
      return;
    }

    // Load from Firebase
    setLoading(true);
    try {
      const stock = await getShopStock(selectedBranch);

      // Cache all items
      setBranchStockCache(selectedBranch, stock);

      // Filter only available items
      const available = stock.filter((s) => s.status === "in-branch" || !s.status);
      setBranchStock(available);
      toast.success(`Loaded ${available.length} items from ${selectedBranch}`);
    } catch (error) {
      console.error("Error loading stock:", error);
      toast.error("Failed to load branch stock");
    } finally {
      setLoading(false);
    }
  };

  // Handle barcode scan
  const handleBarcodeScan = async (barcode: string) => {
    try {
      // Check if already in booking
      if (bookingItems.find((i) => i.barcode === barcode)) {
        toast.error(`Item ${barcode} already in booking`);
        return;
      }

      // Find in branch stock
      const stockItem = branchStock.find(
        (s) => s.barcode === barcode || s.label === barcode
      );

      if (!stockItem) {
        toast.error(`Item ${barcode} not found in ${selectedBranch} stock`);
        return;
      }

      if (stockItem.status !== "in-branch") {
        toast.error(`Item ${barcode} is not available (status: ${stockItem.status})`);
        return;
      }

      // Get warehouse item for details
      const warehouseItem = await getItemByBarcode(barcode);

      // Add to booking
      const newItem: BookingItem = {
        id: crypto.randomUUID(),
        barcode: barcode,
        itemName: stockItem.category || warehouseItem?.category || "Unknown",
        stoneSapphire: stockItem.subcategory || warehouseItem?.subcategory || "",
        trNo: "",
        pieces: 1,
        weight: String(stockItem.weight || warehouseItem?.weight || "0"),
        total: parseFloat(String(stockItem.weight || warehouseItem?.weight || "0")) * 1,
      };

      setBookingItems((prev) => [...prev, newItem]);
      calculateTotals();
      toast.success(`✅ Added: ${barcode}`);
    } catch (error) {
      console.error("Error scanning barcode:", error);
      toast.error("Failed to process barcode");
    }
  };

  // Add new item to booking
  const addBookingItem = () => {
    const newItem: BookingItem = {
      id: crypto.randomUUID(),
      barcode: "",
      itemName: "",
      stoneSapphire: "",
      trNo: "",
      pieces: 1,
      weight: "",
      total: 0,
    };
    setBookingItems([...bookingItems, newItem]);
  };

  // Update item field
  const updateItem = (id: string, field: keyof BookingItem, value: any) => {
    setBookingItems((prev) =>
      prev.map((item) => {
        if (item.id !== id) return item;
        const updated = { ...item, [field]: value };

        // Auto-calculate total if pieces or weight changes
        if (field === "pieces" || field === "weight") {
          const weight = parseFloat(updated.weight) || 0;
          updated.total = updated.pieces * weight;
        }

        return updated;
      })
    );
  };

  // Remove item
  const removeItem = (id: string) => {
    setBookingItems((prev) => prev.filter((i) => i.id !== id));
  };

  // Calculate totals
  const calculateTotals = () => {
    const total = bookingItems.reduce((sum, item) => sum + item.total, 0);
    setTotalAmount(total);
    setPendingAmount(total - cashAdvance);
  };

  // Update totals when items or advance changes
  useState(() => {
    calculateTotals();
  });

  // Save booking
  const handleSaveBooking = async () => {
    // Validation
    if (!partyName.trim()) {
      toast.error("Enter party name");
      return;
    }

    if (!mobileNo.trim()) {
      toast.error("Enter mobile number");
      return;
    }

    if (!salespersonName.trim()) {
      toast.error("Enter salesperson name");
      return;
    }

    if (!deliveryDate) {
      toast.error("Select delivery date");
      return;
    }

    if (bookingItems.length === 0) {
      toast.error("Add at least one item to the booking");
      return;
    }

    // Check if all items have required fields
    const invalidItems = bookingItems.filter(
      (item) => !item.itemName.trim() || !item.weight
    );
    if (invalidItems.length > 0) {
      toast.error("Please fill item name and weight for all items");
      return;
    }

    setLoading(true);
    const loadingToast = toast.loading("Saving booking...");

    try {
      const bookingId = `BOOK-${selectedBranch}-${Date.now()}`;
      const bookingNo = `${selectedBranch.substring(0, 3).toUpperCase()}-${Date.now().toString().slice(-6)}`;

      // Save booking to Firestore
      const bookingRef = doc(db, "shops", selectedBranch, "bookings", bookingId);
      await setDoc(bookingRef, {
        bookingId,
        bookingNo,
        branch: selectedBranch,
        partyName,
        mobileNo,
        deliveryDate,
        salespersonName,
        items: bookingItems.map((item) => ({
          barcode: item.barcode,
          itemName: item.itemName,
          stoneSapphire: item.stoneSapphire,
          trNo: item.trNo,
          pieces: item.pieces,
          weight: item.weight,
          total: item.total,
        })),
        netAmount,
        cashAdvance,
        totalAmount,
        pendingAmount,
        remarks,
        status: "pending",
        createdAt: new Date().toISOString(),
        createdBy: "current-user", // TODO: Get from auth
      });

      toast.dismiss(loadingToast);
      toast.success(`✅ Booking saved! Booking No: ${bookingNo}`);

      // Create ledger entry for booking with advance
      try {
        await createBookingLedgerEntry(
          selectedBranch,
          bookingId,
          bookingNo,
          partyName,
          mobileNo,
          netAmount,
          cashAdvance,
          pendingAmount,
          salespersonName,
          "current-user" // TODO: Get from auth
        );
        console.log("✅ Ledger entry created for booking");
      } catch (ledgerError) {
        console.error("Error creating ledger entry:", ledgerError);
        // Don't fail the booking if ledger fails
        toast("⚠️ Booking saved but ledger entry failed", { duration: 3000 });
      }

      // Save booking data for preview
      setSavedBookingData({
        bookingNo,
        bookingId,
        branch: selectedBranch,
        partyName,
        mobileNo,
        deliveryDate,
        salespersonName,
        items: bookingItems,
        totalAmount,
        netAmount,
        cashAdvance,
        pendingAmount,
        remarks,
        createdAt: new Date().toISOString(),
      });

      // Show preview modal
      setShowPreviewModal(true);

    } catch (error) {
      console.error("Error saving booking:", error);
      toast.dismiss(loadingToast);
      toast.error("Failed to save booking");
    } finally {
      setLoading(false);
    }
  };

  // Handle print from modal - Use popup window for reliable printing
  const handlePrintBooking = () => {
    if (!savedBookingData) return;

    const printWindow = window.open("", "_blank", "width=900,height=1200");
    if (!printWindow) {
      toast.error("Please allow popups for printing");
      return;
    }

    // Fallback for company settings if not in scope
    const companySettings = {
      companyName: "SUWARNSPARSH GEMS & JEWELLERY LTD",
      companyAddress: "SHP NO-57,CHAVDI CHOK,GURUWAR PETH,MAHILA MANDAL, KARAD",
      companyPhone: ""
    };

    const companyName = companySettings?.companyName || "SUWARNSPARSH GEMS & JEWELLERY LTD";
    const companyAddress = companySettings?.companyAddress || "SHP NO-57,CHAVDI CHOK,GURUWAR PETH,MAHILA MANDAL, KARAD";

    // Helper to format currency
    const fmt = (num: number) => (num || 0).toFixed(2);
    const dateStr = new Date(savedBookingData.createdAt).toLocaleDateString('en-GB');

    // Define converter locally if not available
    const converter = {
      toWords: (n: number) => {
        return "AMOUNT IN WORDS";
      }
    };



    const itemsHtml = savedBookingData.items.map((item: any, idx: number) => `
      <tr style="height: 24px;">
        <td style="text-align: center;">${idx + 1}</td>
        <td>${item.itemName || item.name || ''}</td>
        <td style="text-align: center;">${item.tagNo || item.trNo || ''}</td>
        <td style="text-align: center;">${item.size || ''}</td>
        <td style="text-align: center;">${item.pcs || item.pieces || 1}</td>
        <td style="text-align: right;">${item.weight?.toFixed(3) || ''}</td>
        <td style="text-align: center;">${item.touch || ''}</td>
        <td style="text-align: right;">${item.stoneWeight || ''}</td>
        <td style="text-align: right;">${item.stoneAmount || ''}</td>
        <td style="text-align: right;">${item.labourRate || ''}</td>
        <td style="text-align: right;">${fmt(item.netAmount || item.total || item.amount || 0)}</td>
      </tr>
    `).join('');

    // Fill empty rows to maintain height
    const emptyRowsCount = Math.max(0, 8 - savedBookingData.items.length);
    const emptyRowsHtml = Array(emptyRowsCount).fill(0).map(() => `
      <tr style="height: 24px;">
        <td>&nbsp;</td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td>
      </tr>
    `).join('');

    const html = `
      <!DOCTYPE html>
      <html>
      <head>
        <title>Booking - ${savedBookingData.partyName}</title>
        <style>
          @page { size: A4; margin: 10mm; }
          * { box-sizing: border-box; }
          body { 
            font-family: Arial, sans-serif; 
            margin: 0; 
            padding: 10px; 
            color: #000; 
            font-size: 11px;
            line-height: 1.3;
          }
          
          .header-container {
            border: 1px solid #000;
            display: flex;
            margin-bottom: 0;
          }
          
          .company-section {
            flex: 1;
            padding: 5px;
            border-right: 1px solid #000;
            text-align: center;
          }
          .company-name { font-weight: bold; font-size: 14px; margin-bottom: 5px; }
          .company-address { font-size: 10px; width: 80%; margin: 0 auto; }
          
          .booking-info {
            width: 200px;
          }
          .info-row {
            border-bottom: 1px solid #000;
            display: flex;
            height: 25px;
            align-items: center;
          }
          .info-row:last-child { border-bottom: none; }
          .info-label {
            width: 80px;
            padding-left: 5px;
            font-weight: bold;
            border-right: 1px solid #000;
            height: 100%;
            display: flex;
            align-items: center;
          }
          .info-value {
            flex: 1;
            text-align: center;
            font-weight: bold;
          }
          
          .party-box {
            border: 1px solid #000;
            border-top: none;
            padding: 5px;
            display: flex;
            justify-content: space-between;
          }
          .party-left { flex: 1; }
          .party-right { width: 200px; }
          
          table { width: 100%; border-collapse: collapse; border: 1px solid #000; border-top: none; font-size: 10px; }
          th { 
            border: 1px solid #000; 
            padding: 4px; 
            background: #eee; 
            font-weight: bold;
            text-align: center;
          }
          td { 
            border: 1px solid #000; 
            padding: 3px; 
          }
          
          .totals-section {
            border: 1px solid #000;
            border-top: none;
            display: flex;
          }
          
          .totals-left {
            flex: 1;
            border-right: 1px solid #000;
            padding: 5px;
            display: flex;
            flex-direction: column;
            justify-content: space-between;
          }
          
          .totals-right {
            width: 250px;
          }
          .total-row {
            display: flex;
            justify-content: space-between;
            padding: 3px 5px;
            border-bottom: 1px solid #ccc;
          }
          .total-row:last-child { border-bottom: none; }
          .total-label { font-weight: bold; }
          
          .footer-box {
            border: 1px solid #000;
            border-top: none;
            padding: 5px;
          }
          
          .signatures {
            margin-top: 40px;
            display: flex;
            justify-content: space-between;
            padding: 0 50px;
          }
          .sign-line {
            border-top: 1px solid #000;
            padding-top: 5px;
            width: 150px;
            text-align: center;
          }

          @media print {
            body { -webkit-print-color-adjust: exact; }
          }
        </style>
      </head>
      <body>

        <div class="header-container">
          <div class="company-section">
            <div class="company-name">${companyName}</div>
            <div class="company-address">${companyAddress}</div>
            <div style="font-size: 10px; margin-top: 5px;">Mo : ${companySettings?.companyPhone || ''}</div>
          </div>
          <div class="booking-info">
            <div class="info-row" style="justify-content: center; background: #eee; font-weight: bold;">
              ORIGINAL
            </div>
            <div class="info-row">
              <div class="info-label">Booking Date :</div>
              <div class="info-value">${dateStr}</div>
            </div>
            <div class="info-row">
              <div class="info-label">Booking No :</div>
              <div class="info-value">${savedBookingData.bookingNo || '00043'}</div>
            </div>
          </div>
        </div>

        <div class="party-box">
          <div class="party-left">
            <div style="margin-bottom: 3px;"><span style="font-weight: bold; display: inline-block; width: 80px;">Party Name :</span> ${savedBookingData.partyName}</div>
            <div><span style="font-weight: bold; display: inline-block; width: 80px;">Mo :</span> ${savedBookingData.mobileNo || ''}</div>
          </div>
          <div class="party-right">
            <div><span style="font-weight: bold; display: inline-block; width: 50px;">Emp :</span> 2011 - ${savedBookingData.salespersonName || ''}</div>
          </div>
        </div>

        <table>
          <thead>
            <tr>
              <th style="width: 30px;">SNO</th>
              <th>Item Name</th>
              <th style="width: 60px;">Tag No</th>
              <th style="width: 40px;">Size</th>
              <th style="width: 30px;">Pcs</th>
              <th style="width: 60px;">Weight</th>
              <th style="width: 40px;">Touch</th>
              <th style="width: 50px;">Stone Wt</th>
              <th style="width: 50px;">Stone Amt</th>
              <th style="width: 50px;">Lbr Rate</th>
              <th style="width: 80px;">Net Amount</th>
            </tr>
          </thead>
          <tbody>
            ${itemsHtml}
            ${emptyRowsHtml}
          </tbody>
        </table>

        <div class="totals-section">
          <div class="totals-left">
            <div>
              <strong>Rupees :</strong> ${converter ? converter.toWords(savedBookingData.totalAmount || 0).toUpperCase() : 'AMOUNT IN WORDS'} ONLY
            </div>
            <div style="margin-top: 5px;">
              <strong>Received Item :</strong> ${savedBookingData.remarks || '-'}
            </div>
          </div>
          <div class="totals-right">
            <div class="total-row">
              <span class="total-label">Net Amount :</span>
              <span>${fmt(savedBookingData.netAmount)}</span>
            </div>
            <div class="total-row">
              <span class="total-label">CGST :</span>
              <span>0.00</span>
            </div>
            <div class="total-row">
              <span class="total-label">SGST :</span>
              <span>0.00</span>
            </div>
            <div class="total-row" style="font-weight: bold; border-top: 1px solid #000;">
              <span class="total-label">Total :</span>
              <span>${fmt(savedBookingData.totalAmount)}</span>
            </div>
          </div>
        </div>

        <div class="footer-box">
          <div style="display: flex; justify-content: space-between; margin-bottom: 5px;">
            <div><strong>Cash Amount :</strong> ${fmt(savedBookingData.cashAdvance)}</div>
            <div><strong>Total Advance :</strong> ${fmt(savedBookingData.cashAdvance)}</div>
            <div><strong>Pending Amt :</strong> ${fmt(savedBookingData.pendingAmount)}</div>
          </div>
          
          <div class="signatures">
            <div class="sign-line">Party signature.</div>
            <div style="text-align: right;">
              <div style="font-weight: bold; font-size: 10px; margin-bottom: 20px;">For : ${companyName}</div>
              <div class="sign-line" style="margin-left: auto;">signature.</div>
            </div>
          </div>
        </div>

        <script>
          window.onload = function() {
            setTimeout(function() {
              window.print();
            }, 500);
          };
        </script>
      </body>
      </html>
    `;

    // ✅ SAFE: Use iframe with srcdoc (Trusted Types compliant)
    const printFrame = printWindow.document.createElement('iframe');
    printFrame.style.position = 'absolute';
    printFrame.style.width = '0';
    printFrame.style.height = '0';
    printFrame.style.border = 'none';

    printFrame.srcdoc = html;
    printWindow.document.body.appendChild(printFrame);

    printFrame.onload = () => {
      setTimeout(() => {
        printFrame.contentWindow?.print();
      }, 500);
    };

    setShowPreviewModal(false);
  };

  // Close modal and optionally clear
  const handleCloseModal = () => {
    setShowPreviewModal(false);

    const shouldClear = window.confirm(
      "Do you want to clear the form and start a new booking?"
    );

    if (shouldClear) {
      clearBooking();
      setPartyName("");
      setMobileNo("");
      setDeliveryDate("");
      setSalespersonName("");
      setBookingItems([]);
      setCashAdvance(0);
      setNetAmount(0);
      setPendingAmount(0);
      setTotalAmount(0);
      setRemarks("");
    }
  };

  // Load last booking
  const loadLastBooking = async () => {
    try {
      const bookingsRef = collection(db, "shops", selectedBranch, "bookings");
      const q = query(bookingsRef, orderBy("createdAt", "desc"), limit(1));
      const snap = await getDocs(q);

      if (!snap.empty) {
        setLastBooking(snap.docs[0].data());
        setShowHistory(true);
        toast.success("Last booking loaded");
      } else {
        toast("No previous bookings found");
      }
    } catch (error) {
      console.error("Error loading last booking:", error);
      toast.error("Failed to load booking history");
    }
  };

  // Export to Excel
  const exportToExcel = () => {
    if (bookingItems.length === 0) {
      toast.error("No items to export");
      return;
    }

    const data = bookingItems.map((item, idx) => ({
      "SNO": idx + 1,
      "Item Name": item.itemName,
      "Stone/Sapphire": item.stoneSapphire,
      "Tr No": item.trNo,
      "Pcs": item.pieces,
      "Weight": item.weight,
      "Total": item.total,
    }));

    // Add summary
    data.push({
      "SNO": "",
      "Item Name": "",
      "Stone/Sapphire": "",
      "Tr No": "",
      "Pcs": "",
      "Weight": "TOTAL",
      "Total": totalAmount,
    } as any);

    data.push({} as any); // Empty row
    data.push({
      "SNO": "",
      "Item Name": "Net Amount",
      "Stone/Sapphire": "",
      "Tr No": "",
      "Pcs": "",
      "Weight": "",
      "Total": netAmount,
    } as any);
    data.push({
      "SNO": "",
      "Item Name": "Cash Advance",
      "Stone/Sapphire": "",
      "Tr No": "",
      "Pcs": "",
      "Weight": "",
      "Total": cashAdvance,
    } as any);
    data.push({
      "SNO": "",
      "Item Name": "Pending Amt",
      "Stone/Sapphire": "",
      "Tr No": "",
      "Pcs": "",
      "Weight": "",
      "Total": pendingAmount,
    } as any);

    const worksheet = XLSX.utils.json_to_sheet(data);
    const workbook = XLSX.utils.book_new();
    XLSX.utils.book_append_sheet(workbook, worksheet, "Booking");
    XLSX.writeFile(workbook, `Booking_${partyName}_${Date.now()}.xlsx`);
    toast.success("Excel exported");
  };

  // Export to PDF - Professional Format
  const exportToPDF = () => {
    if (bookingItems.length === 0) {
      toast.error("No items to export");
      return;
    }

    const doc = new jsPDF();
    const pageWidth = doc.internal.pageSize.getWidth();

    // Company Header
    doc.setFillColor(0, 128, 128); // Teal color
    doc.rect(0, 0, pageWidth, 25, 'F');
    doc.setTextColor(255, 255, 255);
    doc.setFontSize(20);
    doc.setFont("helvetica", "bold");
    doc.text("SUWARNASPARSH JEWELLERS", pageWidth / 2, 12, { align: "center" });
    doc.setFontSize(12);
    doc.text("SALES BOOKING", pageWidth / 2, 20, { align: "center" });

    // Reset text color
    doc.setTextColor(0, 0, 0);

    // Booking Details Box
    doc.setDrawColor(0, 128, 128);
    doc.setLineWidth(0.5);
    doc.rect(14, 30, pageWidth - 28, 40);

    doc.setFontSize(10);
    doc.setFont("helvetica", "bold");
    doc.text("Branch:", 18, 38);
    doc.text("Date:", 18, 46);
    doc.text("Party Name:", 18, 54);
    doc.text("Mobile:", 18, 62);

    doc.text("Delivery Date:", pageWidth / 2, 38);
    doc.text("Salesperson:", pageWidth / 2, 46);

    doc.setFont("helvetica", "normal");
    doc.text(selectedBranch, 50, 38);
    doc.text(new Date().toLocaleDateString('en-GB'), 50, 46);
    doc.text(partyName, 50, 54);
    doc.text(mobileNo, 50, 62);
    doc.text(deliveryDate, pageWidth / 2 + 35, 38);
    doc.text(salespersonName, pageWidth / 2 + 35, 46);

    // Table with professional styling
    const tableData = bookingItems.map((item, idx) => [
      idx + 1,
      item.itemName,
      item.stoneSapphire || "-",
      item.trNo || "-",
      item.pieces,
      item.weight,
      `₹${item.total.toFixed(2)}`,
    ]);

    autoTable(doc, {
      startY: 75,
      head: [["#", "Item Name", "Stone/Sapphire", "Tr No", "Pcs", "Weight", "Amount"]],
      body: tableData,
      theme: "grid",
      headStyles: {
        fillColor: [0, 128, 128],
        textColor: [255, 255, 255],
        fontStyle: "bold",
        fontSize: 10,
      },
      bodyStyles: {
        fontSize: 9,
      },
      alternateRowStyles: {
        fillColor: [240, 248, 255],
      },
      columnStyles: {
        0: { halign: "center", cellWidth: 12 },
        4: { halign: "center", cellWidth: 15 },
        5: { halign: "right", cellWidth: 20 },
        6: { halign: "right", cellWidth: 25 },
      },
    });

    // Totals Box
    const finalY = (doc as any).lastAutoTable.finalY + 10;
    doc.setDrawColor(0, 128, 128);
    doc.setLineWidth(0.5);
    doc.rect(pageWidth - 80, finalY, 66, 45);

    doc.setFontSize(10);
    doc.setFont("helvetica", "normal");
    doc.text("Items Total:", pageWidth - 76, finalY + 10);
    doc.text(`₹${totalAmount.toFixed(2)}`, pageWidth - 18, finalY + 10, { align: "right" });

    doc.text("Net Amount:", pageWidth - 76, finalY + 18);
    doc.text(`₹${netAmount.toFixed(2)}`, pageWidth - 18, finalY + 18, { align: "right" });

    doc.text("Cash Advance:", pageWidth - 76, finalY + 26);
    doc.setTextColor(0, 128, 0);
    doc.text(`₹${cashAdvance.toFixed(2)}`, pageWidth - 18, finalY + 26, { align: "right" });

    doc.setTextColor(0, 0, 0);
    doc.setFont("helvetica", "bold");
    doc.setFontSize(11);
    doc.text("Pending:", pageWidth - 76, finalY + 38);
    doc.setTextColor(220, 0, 0);
    doc.text(`₹${pendingAmount.toFixed(2)}`, pageWidth - 18, finalY + 38, { align: "right" });

    // Remarks
    doc.setTextColor(0, 0, 0);
    if (remarks) {
      doc.setFontSize(9);
      doc.setFont("helvetica", "italic");
      doc.text(`Remarks: ${remarks}`, 14, finalY + 15);
    }

    // Signatures
    const sigY = finalY + 60;
    doc.setFont("helvetica", "normal");
    doc.setFontSize(9);
    doc.line(14, sigY, 60, sigY);
    doc.line(pageWidth - 60, sigY, pageWidth - 14, sigY);
    doc.text("Customer Signature", 14, sigY + 5);
    doc.text("Authorized Signatory", pageWidth - 60, sigY + 5);

    // Footer
    doc.setFontSize(8);
    doc.setTextColor(128, 128, 128);
    doc.text(`Generated on: ${new Date().toLocaleString()}`, 14, 285);

    doc.save(`Booking_${partyName}_${Date.now()}.pdf`);
    toast.success("PDF exported");
  };

  // Print booking
  const handlePrint = () => {
    if (bookingItems.length === 0) {
      toast.error("No items to print");
      return;
    }

    window.print();
  };

  return (
    <>
      <PageMeta
        title="Sales Booking - Order Management"
        description="Create and manage customer orders and bookings"
      />

      {/* Print Styles */}
      <style>{`
        @media print {
          /* Hide the main app container */
          #root > div {
            display: none !important;
          }
          
          /* Show only the invoice-print section */
          .invoice-print {
            display: block !important;
            position: fixed !important;
            top: 0 !important;
            left: 0 !important;
            width: 100% !important;
            height: auto !important;
            max-width: 100% !important;
            padding: 20px !important;
            background: white !important;
            color: black !important;
            box-shadow: none !important;
            border-radius: 0 !important;
            z-index: 9999 !important;
            overflow: visible !important;
          }
          
          /* Hide no-print elements */
          .no-print {
            display: none !important;
          }
          
          /* Invoice Header */
          .invoice-header {
            text-align: center !important;
            border-bottom: 2px solid #000 !important;
            padding-bottom: 10px !important;
            margin-bottom: 15px !important;
          }
          
          .company-name {
            font-size: 24px !important;
            font-weight: bold !important;
            margin-bottom: 5px !important;
            color: #000 !important;
          }
          
          .company-address {
            font-size: 12px !important;
            color: #000 !important;
          }
          
          /* Invoice Info Grid */
          .invoice-info {
            display: grid !important;
            grid-template-columns: 1fr 1fr !important;
            gap: 10px !important;
            margin-bottom: 15px !important;
            font-size: 11px !important;
            color: #000 !important;
          }
          
          .invoice-info-label {
            font-weight: bold !important;
            color: #000 !important;
          }
          
          .invoice-info-value {
            color: #000 !important;
          }
          
          /* Table Styling */
          .invoice-table {
            width: 100% !important;
            border-collapse: collapse !important;
            margin: 15px 0 !important;
          }
          
          .invoice-table th,
          .invoice-table td {
            border: 1px solid #000 !important;
            padding: 6px !important;
            font-size: 11px !important;
            color: #000 !important;
          }
          
          .invoice-table th {
            background-color: #f0f0f0 !important;
            font-weight: bold !important;
            -webkit-print-color-adjust: exact !important;
            print-color-adjust: exact !important;
          }
          
          /* Totals Section */
          .invoice-totals {
            float: right !important;
            width: 300px !important;
            margin-top: 10px !important;
          }
          
          .invoice-totals-row {
            display: flex !important;
            justify-content: space-between !important;
            padding: 5px 0 !important;
            font-size: 12px !important;
            color: #000 !important;
          }
          
          .invoice-totals-row.total {
            border-top: 2px solid #000 !important;
            font-weight: bold !important;
            font-size: 14px !important;
            padding-top: 8px !important;
            margin-top: 5px !important;
          }
          
          /* Footer */
          .invoice-footer {
            margin-top: 60px !important;
            padding-top: 20px !important;
            border-top: 1px solid #000 !important;
            clear: both !important;
          }
          
          .invoice-signatures {
            display: flex !important;
            justify-content: space-between !important;
            margin-top: 40px !important;
          }
          
          .invoice-signature {
            text-align: center !important;
            width: 200px !important;
          }
          
          .invoice-signature-line {
            border-top: 1px solid #000 !important;
            padding-top: 5px !important;
            margin-top: 50px !important;
            font-size: 11px !important;
            color: #000 !important;
          }
          
          /* Payment Section */
          .invoice-payment {
            margin: 15px 0 !important;
            padding: 10px !important;
            border: 1px solid #000 !important;
          }
          
          .invoice-payment-title {
            font-weight: bold !important;
            margin-bottom: 5px !important;
            color: #000 !important;
          }
          
          /* Page Setup */
          @page {
            size: A4;
            margin: 15mm;
          }
        }
      `}</style>

      <div className="grid grid-cols-12 gap-6">
        <div className="col-span-12">
          <TASection
            title="📋 Sales Booking / Order Management"
            subtitle="Create advance orders and bookings for customers"
          >
            {/* Info Banner */}
            <div className="mb-6 p-4 bg-purple-50 dark:bg-purple-900/20 border border-purple-200 dark:border-purple-800 rounded-xl">
              <div className="flex items-start gap-3">
                <FileText className="text-purple-600 dark:text-purple-400 flex-shrink-0 mt-0.5" size={20} />
                <div>
                  <h3 className="font-semibold text-purple-800 dark:text-purple-400 mb-1">
                    📝 Sales Booking Process
                  </h3>
                  <p className="text-sm text-purple-800 dark:text-purple-300">
                    Record customer orders with advance payment. Track delivery dates and pending amounts.
                    Perfect for custom jewelry orders and special requests.
                  </p>
                </div>
              </div>
            </div>

            {/* Action Buttons */}
            <div className="flex flex-wrap gap-2 mb-6">
              <button
                onClick={loadLastBooking}
                className="px-4 py-2 bg-purple-500 hover:bg-purple-600 text-white rounded-xl text-sm font-medium transition-colors flex items-center gap-2"
              >
                <ShoppingCart size={16} /> Last Booking
              </button>
              <button
                onClick={exportToExcel}
                disabled={bookingItems.length === 0}
                className="px-4 py-2 bg-green-500 hover:bg-green-600 text-white rounded-xl text-sm font-medium transition-colors flex items-center gap-2 disabled:opacity-50 disabled:cursor-not-allowed"
              >
                <Download size={16} /> Excel
              </button>
              <button
                onClick={exportToPDF}
                disabled={bookingItems.length === 0}
                className="px-4 py-2 bg-red-500 hover:bg-red-600 text-white rounded-xl text-sm font-medium transition-colors flex items-center gap-2 disabled:opacity-50 disabled:cursor-not-allowed"
              >
                <Download size={16} /> PDF
              </button>
              <button
                onClick={handlePrint}
                disabled={bookingItems.length === 0}
                className="px-4 py-2 bg-gray-600 hover:bg-gray-700 text-white rounded-xl text-sm font-medium transition-colors flex items-center gap-2 disabled:opacity-50 disabled:cursor-not-allowed"
              >
                <Printer size={16} /> Print
              </button>
            </div>

            {/* Customer & Booking Details */}
            <div className="grid grid-cols-1 md:grid-cols-4 gap-4 mb-6">
              <div>
                <label className="block text-sm font-medium mb-2 text-gray-500 dark:text-gray-400">
                  Branch
                </label>
                <CustomDropdown
                  options={branches}
                  value={selectedBranch}
                  onChange={(val) => setSelectedBranch(val as BranchName)}
                  onAddNew={handleAddBranch}
                  placeholder="Select Branch"
                  addNewPlaceholder="Add branch..."
                />
              </div>

              <div>
                <label className="block text-sm font-medium mb-2 text-gray-500 dark:text-gray-400">
                  Party Name *
                </label>
                <input
                  type="text"
                  value={partyName}
                  onChange={(e) => setPartyName(e.target.value)}
                  placeholder="Enter customer name"
                  className="w-full rounded-xl border border-gray-200 dark:border-gray-800 bg-white dark:bg-white/[0.03] px-3 py-2 text-gray-800 dark:text-white/90 placeholder:text-gray-400 focus:outline-none focus:border-primary"
                />
              </div>

              <div>
                <label className="block text-sm font-medium mb-2 text-gray-500 dark:text-gray-400">
                  <Phone className="inline mr-1" size={14} />
                  Mobile No *
                </label>
                <input
                  type="tel"
                  value={mobileNo}
                  onChange={(e) => setMobileNo(e.target.value)}
                  placeholder="Enter mobile number"
                  className="w-full rounded-xl border border-gray-200 dark:border-gray-800 bg-white dark:bg-white/[0.03] px-3 py-2 text-gray-800 dark:text-white/90 placeholder:text-gray-400 focus:outline-none focus:border-primary"
                />
              </div>

              <div>
                <label className="block text-sm font-medium mb-2 text-gray-500 dark:text-gray-400">
                  <Calendar className="inline mr-1" size={14} />
                  Delivery Date *
                </label>
                <input
                  type="date"
                  value={deliveryDate}
                  onChange={(e) => setDeliveryDate(e.target.value)}
                  className="w-full rounded-xl border border-gray-200 dark:border-gray-800 bg-white dark:bg-white/[0.03] px-3 py-2 text-gray-800 dark:text-white/90 focus:outline-none focus:border-primary"
                />
              </div>
            </div>

            {/* Salesperson & Barcode Scanner */}
            <div className="grid grid-cols-1 md:grid-cols-2 gap-4 mb-6">
              <div>
                <label className="block text-sm font-medium mb-2 text-gray-500 dark:text-gray-400">
                  Salesperson Name *
                </label>
                <input
                  type="text"
                  value={salespersonName}
                  onChange={(e) => setSalespersonName(e.target.value)}
                  placeholder="Enter salesperson name"
                  className="w-full rounded-xl border border-gray-200 dark:border-gray-800 bg-white dark:bg-white/[0.03] px-3 py-2 text-gray-800 dark:text-white/90 placeholder:text-gray-400 focus:outline-none focus:border-primary"
                />
              </div>

              <div>
                <label className="block text-sm font-medium mb-2 text-gray-500 dark:text-gray-400">
                  🔍 Scan Item Barcode
                </label>
                <BarcodeScanner
                  onScan={handleBarcodeScan}
                  placeholder="Scan barcode to add item from stock..."
                  disabled={loading}
                />
              </div>
            </div>

            {/* Booking Items */}
            <div className="mb-6 print-area">
              <div className="flex items-center justify-between mb-4 no-print">
                <h3 className="text-lg font-semibold text-gray-900 dark:text-white">
                  <Package className="inline mr-2" size={20} />
                  Booking Items
                </h3>
                <button
                  onClick={addBookingItem}
                  className="px-4 py-2 bg-purple-500 hover:bg-purple-600 text-white rounded-xl font-medium transition-colors flex items-center gap-2"
                >
                  <Plus size={18} />
                  Add Item
                </button>
              </div>

              {/* Editable Table */}
              <div className="overflow-x-auto rounded-xl border border-gray-200 dark:border-gray-800 bg-white dark:bg-gray-900/50">
                <table className="w-full text-sm">
                  <thead>
                    <tr className="border-b-2 border-gray-300 dark:border-gray-700">
                      <th className="p-3 text-left font-bold text-gray-700 dark:text-gray-300 bg-gray-100 dark:bg-gray-800/50">SNO</th>
                      <th className="p-3 text-left font-bold text-gray-700 dark:text-gray-300 bg-gray-100 dark:bg-gray-800/50">ITEM NAME *</th>
                      <th className="p-3 text-left font-bold text-gray-700 dark:text-gray-300 bg-gray-100 dark:bg-gray-800/50">STONE/SAPPHIRE</th>
                      <th className="p-3 text-left font-bold text-gray-700 dark:text-gray-300 bg-gray-100 dark:bg-gray-800/50">TR NO</th>
                      <th className="p-3 text-center font-bold text-gray-700 dark:text-gray-300 bg-gray-100 dark:bg-gray-800/50">PCS</th>
                      <th className="p-3 text-right font-bold text-gray-700 dark:text-gray-300 bg-gray-100 dark:bg-gray-800/50">WEIGHT *</th>
                      <th className="p-3 text-right font-bold text-gray-700 dark:text-gray-300 bg-gray-100 dark:bg-gray-800/50">TOTAL</th>
                      <th className="p-3 text-center font-bold text-gray-700 dark:text-gray-300 bg-gray-100 dark:bg-gray-800/50 no-print">ACTION</th>
                    </tr>
                  </thead>
                  <tbody>
                    {bookingItems.map((item, idx) => (
                      <tr
                        key={item.id}
                        className="border-b border-gray-200 dark:border-gray-800 hover:bg-gray-50 dark:hover:bg-white/5 transition-colors"
                      >
                        <td className="p-3 font-medium text-gray-700 dark:text-gray-300">{idx + 1}</td>
                        <td className="p-3">
                          <input
                            type="text"
                            value={item.itemName}
                            onChange={(e) => updateItem(item.id, "itemName", e.target.value)}
                            placeholder="Enter item name"
                            className="w-full px-3 py-2 border border-gray-300 dark:border-gray-700 rounded-lg bg-white dark:bg-gray-800 text-gray-900 dark:text-white focus:outline-none focus:ring-2 focus:ring-primary/50"
                          />
                        </td>
                        <td className="p-3">
                          <input
                            type="text"
                            value={item.stoneSapphire}
                            onChange={(e) => updateItem(item.id, "stoneSapphire", e.target.value)}
                            placeholder="Stone/Sapphire details"
                            className="w-full px-3 py-2 border border-gray-300 dark:border-gray-700 rounded-lg bg-white dark:bg-gray-800 text-gray-900 dark:text-white focus:outline-none focus:ring-2 focus:ring-primary/50"
                          />
                        </td>
                        <td className="p-3">
                          <input
                            type="text"
                            value={item.trNo}
                            onChange={(e) => updateItem(item.id, "trNo", e.target.value)}
                            placeholder="Tr No"
                            className="w-24 px-3 py-2 border border-gray-300 dark:border-gray-700 rounded-lg bg-white dark:bg-gray-800 text-gray-900 dark:text-white focus:outline-none focus:ring-2 focus:ring-primary/50"
                          />
                        </td>
                        <td className="p-3 text-center">
                          <input
                            type="number"
                            value={item.pieces}
                            onChange={(e) => {
                              updateItem(item.id, "pieces", Number(e.target.value));
                              calculateTotals();
                            }}
                            className="w-20 px-3 py-2 border border-gray-300 dark:border-gray-700 rounded-lg bg-white dark:bg-gray-800 text-gray-900 dark:text-white text-center focus:outline-none focus:ring-2 focus:ring-primary/50"
                            min="1"
                          />
                        </td>
                        <td className="p-3">
                          <input
                            type="text"
                            value={item.weight}
                            onChange={(e) => {
                              updateItem(item.id, "weight", e.target.value);
                              calculateTotals();
                            }}
                            placeholder="0.00"
                            className="w-28 px-3 py-2 border border-gray-300 dark:border-gray-700 rounded-lg bg-white dark:bg-gray-800 text-gray-900 dark:text-white text-right focus:outline-none focus:ring-2 focus:ring-primary/50"
                          />
                        </td>
                        <td className="p-3 text-right font-semibold text-gray-900 dark:text-white">
                          {item.total.toFixed(2)}
                        </td>
                        <td className="p-3 text-center no-print">
                          <button
                            onClick={() => removeItem(item.id)}
                            className="p-2 text-red-600 hover:bg-red-50 dark:hover:bg-red-900/20 rounded-lg transition-colors"
                            title="Remove item"
                          >
                            <Trash2 size={16} />
                          </button>
                        </td>
                      </tr>
                    ))}

                    {bookingItems.length === 0 && (
                      <tr>
                        <td colSpan={8} className="p-8 text-center text-gray-500 dark:text-gray-400">
                          <Package size={48} className="mx-auto mb-2 opacity-50" />
                          <p>No items added. Scan barcode or click "Add Item" to start.</p>
                        </td>
                      </tr>
                    )}
                  </tbody>

                  {/* Totals Footer */}
                  {bookingItems.length > 0 && (
                    <tfoot className="border-t-2 border-gray-300 dark:border-gray-700 bg-gray-50 dark:bg-gray-800/50">
                      <tr>
                        <td colSpan={6} className="p-3 text-right font-bold text-gray-700 dark:text-gray-300">
                          TOTAL AMOUNT:
                        </td>
                        <td className="p-3 text-right font-bold text-lg text-primary">
                          ₹{totalAmount.toFixed(2)}
                        </td>
                        <td className="no-print"></td>
                      </tr>
                    </tfoot>
                  )}
                </table>
              </div>
            </div>

            {/* Payment Details */}
            {bookingItems.length > 0 && (
              <div className="grid grid-cols-1 md:grid-cols-3 gap-6 mb-6">
                <div className="p-6 bg-gradient-to-br from-blue-50 to-blue-100 dark:from-blue-900/20 dark:to-blue-800/20 rounded-xl border border-blue-200 dark:border-blue-800">
                  <label className="block text-sm font-semibold mb-2 text-blue-900 dark:text-blue-300">
                    Net Amount *
                  </label>
                  <div className="relative">
                    <span className="absolute left-3 top-1/2 -translate-y-1/2 text-gray-500">₹</span>
                    <input
                      type="number"
                      value={netAmount}
                      onChange={(e) => {
                        const val = Number(e.target.value);
                        setNetAmount(val);
                        setPendingAmount(val - cashAdvance);
                      }}
                      placeholder="0.00"
                      className="w-full pl-8 pr-3 py-3 border-2 border-blue-300 dark:border-blue-700 rounded-lg bg-white dark:bg-gray-800 text-gray-900 dark:text-white text-lg font-semibold focus:outline-none focus:ring-2 focus:ring-blue-500"
                      step="0.01"
                    />
                  </div>
                  <p className="text-xs text-blue-700 dark:text-blue-400 mt-2">
                    Final agreed amount with customer
                  </p>
                </div>

                <div className="p-6 bg-gradient-to-br from-green-50 to-green-100 dark:from-green-900/20 dark:to-green-800/20 rounded-xl border border-green-200 dark:border-green-800">
                  <label className="block text-sm font-semibold mb-2 text-green-900 dark:text-green-300">
                    Cash Advance
                  </label>
                  <div className="relative">
                    <span className="absolute left-3 top-1/2 -translate-y-1/2 text-gray-500">₹</span>
                    <input
                      type="number"
                      value={cashAdvance}
                      onChange={(e) => {
                        const val = Number(e.target.value);
                        setCashAdvance(val);
                        setPendingAmount(netAmount - val);
                      }}
                      placeholder="0.00"
                      className="w-full pl-8 pr-3 py-3 border-2 border-green-300 dark:border-green-700 rounded-lg bg-white dark:bg-gray-800 text-gray-900 dark:text-white text-lg font-semibold focus:outline-none focus:ring-2 focus:ring-green-500"
                      step="0.01"
                    />
                  </div>
                  <p className="text-xs text-green-700 dark:text-green-400 mt-2">
                    Amount paid in advance
                  </p>
                </div>

                <div className="p-6 bg-gradient-to-br from-orange-50 to-orange-100 dark:from-orange-900/20 dark:to-orange-800/20 rounded-xl border border-orange-200 dark:border-orange-800">
                  <label className="block text-sm font-semibold mb-2 text-orange-900 dark:text-orange-300">
                    Pending Amount
                  </label>
                  <div className="relative">
                    <span className="absolute left-3 top-1/2 -translate-y-1/2 text-gray-500">₹</span>
                    <input
                      type="number"
                      value={pendingAmount}
                      readOnly
                      className="w-full pl-8 pr-3 py-3 border-2 border-orange-300 dark:border-orange-700 rounded-lg bg-orange-50 dark:bg-orange-900/30 text-gray-900 dark:text-white text-lg font-semibold cursor-not-allowed"
                    />
                  </div>
                  <p className="text-xs text-orange-700 dark:text-orange-400 mt-2">
                    Balance to be collected
                  </p>
                </div>
              </div>
            )}

            {/* Remarks */}
            {bookingItems.length > 0 && (
              <div className="mb-6">
                <label className="block text-sm font-semibold mb-2 text-gray-700 dark:text-gray-300">
                  Remarks / Special Instructions
                </label>
                <textarea
                  value={remarks}
                  onChange={(e) => setRemarks(e.target.value)}
                  placeholder="Add any special instructions or notes..."
                  rows={3}
                  className="w-full px-4 py-3 border border-gray-300 dark:border-gray-700 rounded-xl bg-white dark:bg-gray-800 text-gray-900 dark:text-white focus:outline-none focus:ring-2 focus:ring-primary/50"
                />
              </div>
            )}

            {/* Save Button */}
            {bookingItems.length > 0 && (
              <div className="flex justify-end">
                <button
                  onClick={handleSaveBooking}
                  disabled={loading}
                  className="px-8 py-4 bg-gradient-to-r from-primary to-primary/80 hover:from-primary/90 hover:to-primary/70 text-white rounded-xl font-bold text-lg transition-all shadow-lg hover:shadow-xl disabled:opacity-50 disabled:cursor-not-allowed flex items-center gap-3"
                >
                  <Save size={24} />
                  {loading ? "Saving..." : "Save Booking"}
                </button>
              </div>
            )}

            {/* Last Booking History */}
            {showHistory && lastBooking && (
              <div className="mt-6 p-6 bg-purple-50 dark:bg-purple-900/20 rounded-xl border border-purple-200 dark:border-purple-800">
                <div className="flex justify-between items-center mb-4">
                  <h3 className="text-lg font-bold text-purple-900 dark:text-purple-300">
                    📜 Last Booking
                  </h3>
                  <button
                    onClick={() => setShowHistory(false)}
                    className="text-purple-600 hover:text-purple-800 dark:text-purple-400"
                  >
                    ✕ Close
                  </button>
                </div>

                <div className="grid grid-cols-2 md:grid-cols-4 gap-4 mb-4 text-sm">
                  <div>
                    <span className="text-gray-600 dark:text-gray-400">Booking No:</span>
                    <p className="font-semibold">{lastBooking.bookingNo}</p>
                  </div>
                  <div>
                    <span className="text-gray-600 dark:text-gray-400">Party Name:</span>
                    <p className="font-semibold">{lastBooking.partyName}</p>
                  </div>
                  <div>
                    <span className="text-gray-600 dark:text-gray-400">Mobile:</span>
                    <p className="font-semibold">{lastBooking.mobileNo}</p>
                  </div>
                  <div>
                    <span className="text-gray-600 dark:text-gray-400">Delivery Date:</span>
                    <p className="font-semibold">{lastBooking.deliveryDate}</p>
                  </div>
                  <div>
                    <span className="text-gray-600 dark:text-gray-400">Salesperson:</span>
                    <p className="font-semibold">{lastBooking.salespersonName}</p>
                  </div>
                  <div>
                    <span className="text-gray-600 dark:text-gray-400">Status:</span>
                    <p className="font-semibold capitalize">
                      <span className={`px-2 py-1 rounded text-xs ${lastBooking.status === "pending"
                        ? "bg-yellow-100 text-yellow-700 dark:bg-yellow-900/30 dark:text-yellow-400"
                        : "bg-green-100 text-green-700 dark:bg-green-900/30 dark:text-green-400"
                        }`}>
                        {lastBooking.status}
                      </span>
                    </p>
                  </div>
                  <div>
                    <span className="text-gray-600 dark:text-gray-400">Created:</span>
                    <p className="font-semibold">
                      {new Date(lastBooking.createdAt).toLocaleDateString()}
                    </p>
                  </div>
                </div>

                <div className="overflow-x-auto rounded-lg border border-purple-200 dark:border-purple-800 mb-4">
                  <table className="w-full text-sm">
                    <thead className="bg-purple-100 dark:bg-purple-900/40">
                      <tr className="text-left">
                        <th className="p-2">#</th>
                        <th className="p-2">Item Name</th>
                        <th className="p-2">Stone/Sapphire</th>
                        <th className="p-2">Tr No</th>
                        <th className="p-2">Pcs</th>
                        <th className="p-2">Weight</th>
                        <th className="p-2">Total</th>
                      </tr>
                    </thead>
                    <tbody>
                      {lastBooking.items?.map((item: any, idx: number) => (
                        <tr key={idx} className="border-b border-purple-200 dark:border-purple-800">
                          <td className="p-2">{idx + 1}</td>
                          <td className="p-2">{item.itemName}</td>
                          <td className="p-2">{item.stoneSapphire || "-"}</td>
                          <td className="p-2">{item.trNo || "-"}</td>
                          <td className="p-2">{item.pieces}</td>
                          <td className="p-2">{item.weight}</td>
                          <td className="p-2 font-semibold">₹{item.total.toFixed(2)}</td>
                        </tr>
                      ))}
                    </tbody>
                  </table>
                </div>

                <div className="grid grid-cols-2 md:grid-cols-4 gap-4 text-sm bg-purple-100 dark:bg-purple-900/40 rounded-lg p-4">
                  <div>
                    <span className="text-gray-600 dark:text-gray-400">Items Total:</span>
                    <p className="font-bold text-lg">₹{lastBooking.totalAmount?.toFixed(2)}</p>
                  </div>
                  <div>
                    <span className="text-gray-600 dark:text-gray-400">Net Amount:</span>
                    <p className="font-bold text-lg">₹{lastBooking.netAmount?.toFixed(2)}</p>
                  </div>
                  <div>
                    <span className="text-gray-600 dark:text-gray-400">Cash Advance:</span>
                    <p className="font-bold text-lg text-green-600 dark:text-green-400">
                      ₹{lastBooking.cashAdvance?.toFixed(2)}
                    </p>
                  </div>
                  <div>
                    <span className="text-gray-600 dark:text-gray-400">Pending Amount:</span>
                    <p className="font-bold text-lg text-red-600 dark:text-red-400">
                      ₹{lastBooking.pendingAmount?.toFixed(2)}
                    </p>
                  </div>
                </div>

                {lastBooking.remarks && (
                  <div className="mt-4 p-3 bg-white dark:bg-gray-800 rounded-lg border border-purple-200 dark:border-purple-800">
                    <span className="text-xs text-gray-600 dark:text-gray-400">Remarks:</span>
                    <p className="text-sm mt-1">{lastBooking.remarks}</p>
                  </div>
                )}
              </div>
            )}
          </TASection>
        </div>
      </div>

      {/* Preview Modal (Like Distribution Challan) */}
      {showPreviewModal && savedBookingData && (
        <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/50 p-4">
          <div className="bg-white dark:bg-gray-900 rounded-xl shadow-2xl max-w-4xl w-full max-h-[90vh] overflow-hidden flex flex-col">
            {/* Modal Header */}
            <div className="no-print flex items-center justify-between p-6 border-b border-gray-200 dark:border-gray-800">
              <h2 className="text-2xl font-bold text-gray-900 dark:text-white">
                📋 Booking Preview
              </h2>
              <div className="flex items-center gap-3">
                <button
                  onClick={handlePrintBooking}
                  className="px-6 py-3 bg-primary hover:bg-primary/90 text-white rounded-xl font-semibold transition-colors flex items-center gap-2"
                >
                  <Printer size={20} />
                  Print
                </button>
                <button
                  onClick={handleCloseModal}
                  className="p-2 hover:bg-gray-100 dark:hover:bg-gray-800 rounded-lg transition-colors"
                >
                  ✕
                </button>
              </div>
            </div>

            {/* Modal Content - Professional Preview */}
            <div className="flex-1 overflow-y-auto p-6 bg-gray-50 dark:bg-gray-900">
              <div className="invoice-print bg-white dark:bg-gray-800 rounded-lg shadow-lg p-8 max-w-[210mm] mx-auto">
                {/* SECTION 1: HEADER */}
                <div className="invoice-header">
                  <div className="company-name">SALES BOOKING</div>
                  <div className="company-address">
                    Branch: {savedBookingData.branch}
                  </div>
                </div>

                {/* SECTION 2: META INFO */}
                <div className="invoice-meta">
                  <div className="invoice-meta-row">
                    <div className="invoice-meta-label">Booking No:</div>
                    <div className="invoice-meta-value">{savedBookingData.bookingNo}</div>
                    <div className="invoice-meta-label">Date:</div>
                    <div className="invoice-meta-value">{new Date(savedBookingData.createdAt).toLocaleDateString()}</div>
                  </div>
                  <div className="invoice-meta-row">
                    <div className="invoice-meta-label">Party Name:</div>
                    <div className="invoice-meta-value">{savedBookingData.partyName}</div>
                    <div className="invoice-meta-label">Mobile:</div>
                    <div className="invoice-meta-value">{savedBookingData.mobileNo}</div>
                  </div>
                  <div className="invoice-meta-row">
                    <div className="invoice-meta-label">Delivery Date:</div>
                    <div className="invoice-meta-value">{savedBookingData.deliveryDate}</div>
                    <div className="invoice-meta-label">Salesperson:</div>
                    <div className="invoice-meta-value">{savedBookingData.salespersonName}</div>
                  </div>
                </div>

                {/* SECTION 3: ITEMS TABLE */}
                <table className="invoice-table">
                  <thead>
                    <tr>
                      <th className="col-sno">#</th>
                      <th className="col-item">ITEM NAME</th>
                      <th className="col-remark">STONE/SAPPHIRE</th>
                      <th className="col-hsn">TR NO</th>
                      <th className="col-pcs">PCS</th>
                      <th className="col-weight">WEIGHT</th>
                      <th className="col-amount">TOTAL</th>
                    </tr>
                  </thead>
                  <tbody>
                    {savedBookingData.items.map((item: any, idx: number) => (
                      <tr key={idx}>
                        <td className="col-sno">{idx + 1}</td>
                        <td className="col-item">{item.itemName}</td>
                        <td className="col-remark">{item.stoneSapphire}</td>
                        <td className="col-hsn">{item.trNo}</td>
                        <td className="col-pcs">{item.pieces}</td>
                        <td className="col-weight">{item.weight}</td>
                        <td className="col-amount">₹{item.total.toFixed(2)}</td>
                      </tr>
                    ))}
                  </tbody>
                </table>

                {/* SECTION 4: TOTALS */}
                <div className="invoice-totals">
                  <div className="invoice-totals-row subtotal">
                    <div className="invoice-totals-label">Items Total:</div>
                    <div className="invoice-totals-value">₹{savedBookingData.totalAmount.toFixed(2)}</div>
                  </div>
                  <div className="invoice-totals-row">
                    <div className="invoice-totals-label">Net Amount:</div>
                    <div className="invoice-totals-value">₹{savedBookingData.netAmount.toFixed(2)}</div>
                  </div>
                  <div className="invoice-totals-row">
                    <div className="invoice-totals-label">Cash Advance:</div>
                    <div className="invoice-totals-value">₹{savedBookingData.cashAdvance.toFixed(2)}</div>
                  </div>
                  <div className="invoice-totals-row total">
                    <div className="invoice-totals-label">Pending Amount:</div>
                    <div className="invoice-totals-value">₹{savedBookingData.pendingAmount.toFixed(2)}</div>
                  </div>
                </div>

                {/* SECTION 5: REMARKS */}
                {savedBookingData.remarks && (
                  <div className="invoice-payment">
                    <div className="invoice-payment-title">REMARKS</div>
                    <div>{savedBookingData.remarks}</div>
                  </div>
                )}

                {/* SECTION 6: FOOTER */}
                <div className="invoice-footer">
                  <div className="invoice-signatures">
                    <div className="invoice-signature">
                      <div className="invoice-signature-line">Customer Signature</div>
                    </div>
                    <div className="invoice-signature">
                      <div className="invoice-signature-line">
                        Authorized Signatory
                      </div>
                    </div>
                  </div>
                </div>
              </div>
            </div>

            {/* Modal Footer */}
            <div className="no-print flex items-center justify-between p-6 border-t border-gray-200 dark:border-gray-800 bg-gray-50 dark:bg-gray-900">
              <p className="text-sm text-gray-500 dark:text-gray-400">
                Review booking before printing
              </p>
              <div className="flex gap-3">
                <button
                  onClick={handleCloseModal}
                  className="px-6 py-2 border border-gray-300 dark:border-gray-700 hover:bg-gray-100 dark:hover:bg-gray-800 text-gray-700 dark:text-gray-300 rounded-xl font-medium transition-colors"
                >
                  Close
                </button>
                <button
                  onClick={handlePrintBooking}
                  className="px-6 py-2 bg-primary hover:bg-primary/90 text-white rounded-xl font-semibold transition-colors flex items-center gap-2"
                >
                  <Printer size={18} />
                  Print Now
                </button>
              </div>
            </div>
          </div>
        </div>
      )}

    </>
  );
}
