// src/components/print/InvoicePrint.tsx - Safe Invoice Print Component
import React from "react";

interface InvoicePrintProps {
  invoiceData: any; // Replace with proper type from your billing system
}

export default function InvoicePrint({ invoiceData }: InvoicePrintProps) {
  if (!invoiceData) return null;

  return (
    <div style={{ fontFamily: "Arial, sans-serif", padding: "20px", maxWidth: "800px", margin: "0 auto" }}>
      <style>
        {`
          @media print {
            body { margin: 0; padding: 20px; }
            @page { size: A4; margin: 10mm; }
          }
          table { width: 100%; borderCollapse: collapse; marginTop: 10px; }
          th, td { border: 1px solid #333; padding: 8px; fontSize: 13px; }
          th { backgroundColor: #f5f5f5; fontWeight: bold; textAlign: left; }
          .header { textAlign: center; marginBottom: 20px; }
          .company-name { fontSize: 24px; fontWeight: bold; marginBottom: 5px; }
          .invoice-title { fontSize: 18px; fontWeight: bold; marginTop: 20px; marginBottom: 10px; }
          .info-row { display: flex; justifyContent: space-between; marginBottom: 5px; }
          .total-row { fontWeight: bold; backgroundColor: #f0f0f0; }
        `}
      </style>

      <div className="header">
        <div className="company-name">{invoiceData.companyName || "Suwarnasparsh Jewellers"}</div>
        <div>{invoiceData.companyAddress || ""}</div>
        <div>{invoiceData.companyPhone || ""}</div>
      </div>

      <div className="invoice-title">INVOICE</div>

      <div className="info-row">
        <div><strong>Invoice No:</strong> {invoiceData.invoiceNo}</div>
        <div><strong>Date:</strong> {new Date(invoiceData.date).toLocaleDateString()}</div>
      </div>

      <div className="info-row">
        <div><strong>Customer:</strong> {invoiceData.customerName}</div>
        <div><strong>Phone:</strong> {invoiceData.customerPhone || "-"}</div>
      </div>

      <table>
        <thead>
          <tr>
            <th>Sr</th>
            <th>Item</th>
            <th>Weight</th>
            <th>Rate</th>
            <th>Amount</th>
          </tr>
        </thead>
        <tbody>
          {invoiceData.items?.map((item: any, index: number) => (
            <tr key={index}>
              <td>{index + 1}</td>
              <td>{item.name || item.label}</td>
              <td>{item.weight || "-"}</td>
              <td>{item.rate || "-"}</td>
              <td>{item.amount || "-"}</td>
            </tr>
          ))}
        </tbody>
        <tfoot>
          <tr className="total-row">
            <td colSpan={4} style={{ textAlign: "right" }}>Total:</td>
            <td>{invoiceData.total || 0}</td>
          </tr>
        </tfoot>
      </table>

      <div style={{ marginTop: "40px" }}>
        <div><strong>Payment Method:</strong> {invoiceData.paymentMethod || "-"}</div>
        <div><strong>Remarks:</strong> {invoiceData.remarks || "-"}</div>
      </div>

      <div style={{ marginTop: "60px", display: "flex", justifyContent: "space-between" }}>
        <div>
          <div style={{ borderTop: "1px solid #000", width: "200px", paddingTop: "5px" }}>
            Customer Signature
          </div>
        </div>
        <div>
          <div style={{ borderTop: "1px solid #000", width: "200px", paddingTop: "5px" }}>
            Authorized Signature
          </div>
        </div>
      </div>
    </div>
  );
}
